package spring.springstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStartApplicationTests {

	@Test
	void contextLoads() {
	}

}
